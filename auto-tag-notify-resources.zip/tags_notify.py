import os
import json
import boto3

ec2_client = boto3.client('ec2')
s3_client = boto3.client('s3')
rds_client = boto3.client('rds')
account = boto3.client("sts")
account_id = account.get_caller_identity()["Account"]
sendmail = boto3.client('ses', region_name='us-east-1')

address = json.loads(os.environ['EMAIL_ADDRESS'])
sender = os.environ['EMAIL_SENDER']
list_to_check = json.loads(os.environ['TAGS_TO_CHECK'])

def send_email_s3(bucket, user, tag_to_check):
    texto = "O Bucket esta sem a(s) Tag(s) necessárias:\n\nTAG: {}\nConta AWS: {}\nBucket Name: {}\nUsuario criador: {}\n\nEquipe Cloud".format(tag_to_check, account_id, bucket, user)
    email = sendmail.send_email(
        Destination={
            'ToAddresses': address,
        },
        Message={
            'Body': {
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': texto
            },
        },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': '[AWS] Recurso sem TAGs',
            },
        },
        Source=sender,
    )

def send_email_ec2(instance, user, tag_to_check):
    texto = "A Instância criada esta sem a(s) Tag(s) necessárias:\n\nTAG: {}\nConta AWS: {}\nInstance ID: {}\nUsuario criador: {}\n\nEquipe Cloud".format(tag_to_check, account_id, instance, user)
    email = sendmail.send_email(
        Destination={
            'ToAddresses': address,
        },
        Message={
            'Body': {
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': texto
            },
        },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': '[AWS] Recurso sem TAGs',
            },
        },
        Source=sender,
    )


def send_email_rds(rds_instance, user):
    texto = "A Instancia RDS esta sem a(s) TAGs tribo, squad e/ou produto : \n\nConta AWS: {}\nInstance Name: {}\nUsuario criador: {}\n\nEquipe Cloud".format(account_id, rds_instance, user)
    email = sendmail.send_email(
        Destination={
            'ToAddresses': address,
        },
        Message={
            'Body': {
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': texto
            },
        },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': '[AWS] Recurso sem TAGs',
            },
        },
        Source=sender,
    )


def lambda_handler(event, context):
    def check_for_tag(my_list):
        print('Looking for tag [' + tag_to_check + '] in list ' + json.dumps(my_list))
        print(my_list)
        for i in my_list:
            if i['Key'] == tag_to_check:
                return True
        return False
    
    print(json.dumps(event))

    user = ''
    try:
        # IAM user
        user = event['detail']['userIdentity']['userName']
    except:
        user = event['detail']['userIdentity']['arn'].rsplit('/', 1)[-1]

    if event['source'] == "aws.s3":
        bucket = event['detail']['requestParameters']['bucketName']

        # check for existing tags
        try:
            my_list = s3_client.get_bucket_tagging(Bucket=bucket)
            for tag_to_check in list_to_check:
                if check_for_tag(my_list['TagSet']):
                    print('Bucket [' + bucket + '] is already tagged with [' + tag_to_check + ']')
                else:
                    print('Notificando user: Bucket [' + bucket + '] sem TAG ' + tag_to_check)
                    send_email_s3(bucket, user, tag_to_check)
        except:
            # if an exception is raised, the bucket is not tagged
            print('No tags found on bucket [' + bucket + ']')
            print('Notificando user: Bucket [' + bucket + '] sem TAG ' + tag_to_check)
            send_email_s3(bucket, user, tag_to_check)

    elif event['source'] == "aws.ec2":
        instances = event['detail']['responseElements']['instancesSet']['items']
        instances_list = []
        for j in instances:
            instances_list.append(j['instanceId'])
        for tag_to_check in list_to_check:
            for instance in instances_list:
                response = ec2_client.describe_instances(InstanceIds=[instance])
                for result in response['Reservations']:
                    for my_list in result['Instances']:
                        try:
                            if check_for_tag(my_list['Tags']):
                                print('Instance [' + instance + '] is already tagged with [' + tag_to_check + ']')
                            else:
                                print('Notificando user: Instancia [' + instance + '] sem TAG ' + tag_to_check)
                                send_email_ec2(instance, user, tag_to_check)
                        except:
                            print('No tags found on instance [' + instance + ']')
                            print('Notificando user: Instancia [' + instance + '] sem TAG ' + tag_to_check)
                            send_email_ec2(instance, user, tag_to_check)
                    
            
    elif event['source'] == "aws.rds":
        rds_instance = event['detail']['responseElements']['dBInstanceArn']
        rds_tags = rds_client.list_tags_for_resource(ResourceName=rds_instance)
        try:
            if check_for_tag(rds_tags['TagList']):
                print('RDS Instance [' + rds_instance + '] is already tagged with [' + tag_to_check + ']')
                return
            else:
                print('Notificando user: Instancia RDS [' + rds_instance + '] sem TAG ' + tag_to_check)
                send_email_rds(rds_instance, user)
                return                    
        except:
            # if an exception is raised, the instance is not tagged
            print('No tags found on RDS instance [' + rds_instance + ']')
            print('Notificando user: Instancia [' + rds_instance + '] sem TAG ' + tag_to_check)
            send_email_rds(rds_instance, user)
            return


    return